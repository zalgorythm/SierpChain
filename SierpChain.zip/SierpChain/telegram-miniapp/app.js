// SierpChain Telegram Mini App
class SierpChainApp {
    constructor() {
        this.API_BASE = 'https://sentences-ads-arabia-rom.trycloudflare.com';
        this.BOT_TOKEN = '8255421113:AAF7xzXDGD8RxxfkpjM0L08SqTbudJPd_HM';
        this.tg = window.Telegram.WebApp;
        this.blocks = [];
        this.currentPage = 0;
        this.pageSize = 10;
        this.ws = null;
        
        this.init();
    }

    async init() {
        try {
            // Initialize Telegram WebApp
            this.tg.ready();
            this.tg.expand();
            
            // Set theme colors
            this.setThemeColors();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Load initial data
            await this.loadWalletInfo();
            await this.loadBlocks();
            
            // Setup WebSocket connection
            this.setupWebSocket();
            
            // Hide loading screen
            this.hideLoading();
            
            this.showToast('Welcome to SierpChain!', 'success');
        } catch (error) {
            console.error('Initialization error:', error);
            this.showToast('Failed to initialize app', 'error');
            this.hideLoading();
        }
    }

    setThemeColors() {
        const themeParams = this.tg.themeParams;
        if (themeParams) {
            document.documentElement.style.setProperty('--tg-theme-bg-color', themeParams.bg_color || '#ffffff');
            document.documentElement.style.setProperty('--tg-theme-text-color', themeParams.text_color || '#000000');
            document.documentElement.style.setProperty('--tg-theme-hint-color', themeParams.hint_color || '#999999');
            document.documentElement.style.setProperty('--tg-theme-link-color', themeParams.link_color || '#2481cc');
            document.documentElement.style.setProperty('--tg-theme-button-color', themeParams.button_color || '#2481cc');
            document.documentElement.style.setProperty('--tg-theme-button-text-color', themeParams.button_text_color || '#ffffff');
            document.documentElement.style.setProperty('--tg-theme-secondary-bg-color', themeParams.secondary_bg_color || '#f1f1f1');
        }
    }

    setupEventListeners() {
        // Fractal type change
        document.getElementById('fractal-type').addEventListener('change', (e) => {
            this.showFractalControls(e.target.value);
        });

        // Range input updates
        this.setupRangeInputs();

        // Mining button
        document.getElementById('mine-btn').addEventListener('click', () => {
            this.mineBlock();
        });

        // Send transaction button
        document.getElementById('send-btn').addEventListener('click', () => {
            this.sendTransaction();
        });

        // Load more blocks button
        document.getElementById('load-more-btn').addEventListener('click', () => {
            this.loadMoreBlocks();
        });

        // Modal close
        document.querySelector('.close').addEventListener('click', () => {
            this.closeModal();
        });

        // Modal background click
        document.getElementById('fractal-modal').addEventListener('click', (e) => {
            if (e.target.id === 'fractal-modal') {
                this.closeModal();
            }
        });
    }

    setupRangeInputs() {
        const ranges = [
            { id: 'sierpinski-depth', valueId: 'sierpinski-depth-value' },
            { id: 'mandelbrot-size', valueId: 'mandelbrot-size-value', format: (v) => `${v}x${v}` },
            { id: 'mandelbrot-iterations', valueId: 'mandelbrot-iterations-value' },
            { id: 'julia-size', valueId: 'julia-size-value', format: (v) => `${v}x${v}` },
            { id: 'julia-c-real', valueId: 'julia-c-real-value' },
            { id: 'julia-c-imag', valueId: 'julia-c-imag-value' }
        ];

        ranges.forEach(({ id, valueId, format }) => {
            const input = document.getElementById(id);
            const valueSpan = document.getElementById(valueId);
            
            if (input && valueSpan) {
                input.addEventListener('input', (e) => {
                    const value = e.target.value;
                    valueSpan.textContent = format ? format(value) : value;
                });
            }
        });
    }

    showFractalControls(type) {
        // Hide all controls
        document.querySelectorAll('.fractal-controls').forEach(el => {
            el.style.display = 'none';
        });

        // Show selected controls
        const controlsId = `${type.toLowerCase()}-controls`;
        const controls = document.getElementById(controlsId);
        if (controls) {
            controls.style.display = 'block';
        }
    }

    async loadWalletInfo() {
        try {
            const response = await fetch(`${this.API_BASE}/wallet/info`);
            if (response.ok) {
                const walletInfo = await response.json();
                document.getElementById('wallet-address').textContent = walletInfo.address;
                document.getElementById('wallet-balance').textContent = walletInfo.balance;
            } else {
                // Create a new wallet if none exists
                await this.createWallet();
            }
        } catch (error) {
            console.error('Failed to load wallet info:', error);
            this.showToast('Failed to load wallet', 'error');
        }
    }

    async createWallet() {
        try {
            const response = await fetch(`${this.API_BASE}/wallet`, {
                method: 'POST'
            });
            
            if (response.ok) {
                const walletData = await response.json();
                // Store wallet data securely (in a real app, this should be more secure)
                localStorage.setItem('sierpchain_wallet', JSON.stringify(walletData));
                
                document.getElementById('wallet-address').textContent = walletData.address;
                document.getElementById('wallet-balance').textContent = '0';
                
                this.showToast('New wallet created!', 'success');
            }
        } catch (error) {
            console.error('Failed to create wallet:', error);
            this.showToast('Failed to create wallet', 'error');
        }
    }

    async loadBlocks() {
        try {
            const response = await fetch(`${this.API_BASE}/blocks`);
            if (response.ok) {
                const blocks = await response.json();
                this.blocks = Array.isArray(blocks) ? blocks : [];
                this.renderBlocks();
            }
        } catch (error) {
            console.error('Failed to load blocks:', error);
            this.showToast('Failed to load blocks', 'error');
        }
    }

    async loadMoreBlocks() {
        // For now, just show existing blocks since the API returns all blocks
        // In a real implementation, you'd implement pagination
        this.showToast('All blocks loaded', 'info');
    }

    renderBlocks() {
        const container = document.getElementById('blocks-container');
        container.innerHTML = '';

        const blocksToShow = this.blocks.slice(0, (this.currentPage + 1) * this.pageSize);
        
        blocksToShow.reverse().forEach(block => {
            const blockElement = this.createBlockElement(block);
            container.appendChild(blockElement);
        });

        // Hide load more button if all blocks are shown
        const loadMoreBtn = document.getElementById('load-more-btn');
        if (blocksToShow.length >= this.blocks.length) {
            loadMoreBtn.style.display = 'none';
        }
    }

    createBlockElement(block) {
        const blockDiv = document.createElement('div');
        blockDiv.className = 'block-item';
        blockDiv.onclick = () => this.showBlockDetails(block);

        const timeStr = new Date(block.timestamp).toLocaleString();
        const shortHash = `${block.hash.substring(0, 8)}...${block.hash.substring(-8)}`;

        blockDiv.innerHTML = `
            <div class="block-header">
                <span class="block-index">Block #${block.index}</span>
                <span class="block-time">${timeStr}</span>
            </div>
            <div class="block-hash">${shortHash}</div>
            <div class="fractal-preview">
                ${this.getFractalTypeDisplay(block.fractal)}
            </div>
        `;

        return blockDiv;
    }

    getFractalTypeDisplay(fractal) {
        if (fractal.type === 'Sierpinski') {
            return `🔺 Sierpinski (Depth: ${fractal.data.depth})`;
        } else if (fractal.type === 'Mandelbrot') {
            return `🌀 Mandelbrot (${fractal.data.width}x${fractal.data.height})`;
        } else if (fractal.type === 'Julia') {
            return `🎭 Julia (${fractal.data.width}x${fractal.data.height})`;
        }
        return '🔺 Fractal';
    }

    showBlockDetails(block) {
        const modal = document.getElementById('fractal-modal');
        const fractalDisplay = document.getElementById('fractal-display');
        const blockDetails = document.getElementById('block-details');

        // Render fractal
        this.renderFractal(fractalDisplay, block.fractal);

        // Show block details
        blockDetails.innerHTML = `
            <h4>Block #${block.index}</h4>
            <p><strong>Hash:</strong> <code>${block.hash}</code></p>
            <p><strong>Previous Hash:</strong> <code>${block.previous_hash}</code></p>
            <p><strong>Nonce:</strong> ${block.nonce}</p>
            <p><strong>Timestamp:</strong> ${new Date(block.timestamp).toLocaleString()}</p>
            <p><strong>Transactions:</strong> ${block.transactions.length}</p>
            <p><strong>Fractal Type:</strong> ${block.fractal.type}</p>
        `;

        modal.style.display = 'flex';
    }

    renderFractal(container, fractal) {
        container.innerHTML = '';

        if (fractal.type === 'Sierpinski') {
            this.renderSierpinski(container, fractal.data);
        } else if (fractal.type === 'Mandelbrot') {
            this.renderMandelbrot(container, fractal.data);
        } else if (fractal.type === 'Julia') {
            this.renderJulia(container, fractal.data);
        }
    }

    renderSierpinski(container, sierpinski) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '-0.1 -0.1 1.2 1.2');
        svg.style.width = '100%';
        svg.style.height = '100%';

        // Group vertices into triangles (every 3 vertices)
        for (let i = 0; i < sierpinski.vertices.length; i += 3) {
            if (i + 2 < sierpinski.vertices.length) {
                const polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                const points = `${sierpinski.vertices[i][0]},${sierpinski.vertices[i][1]} ${sierpinski.vertices[i+1][0]},${sierpinski.vertices[i+1][1]} ${sierpinski.vertices[i+2][0]},${sierpinski.vertices[i+2][1]}`;
                polygon.setAttribute('points', points);
                polygon.setAttribute('fill', '#6366f1');
                polygon.setAttribute('stroke', '#4f46e5');
                polygon.setAttribute('stroke-width', '0.002');
                svg.appendChild(polygon);
            }
        }

        container.appendChild(svg);
    }

    renderMandelbrot(container, mandelbrot) {
        const canvas = document.createElement('canvas');
        canvas.width = mandelbrot.width;
        canvas.height = mandelbrot.height;
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.imageRendering = 'pixelated';

        const ctx = canvas.getContext('2d');
        const imageData = ctx.createImageData(mandelbrot.width, mandelbrot.height);

        for (let i = 0; i < mandelbrot.data.length; i++) {
            const iteration = mandelbrot.data[i];
            const pixelIndex = i * 4;

            if (iteration === mandelbrot.max_iterations) {
                // Black for points in the set
                imageData.data[pixelIndex] = 0;
                imageData.data[pixelIndex + 1] = 0;
                imageData.data[pixelIndex + 2] = 0;
            } else {
                // Color based on iteration count
                const hue = (iteration * 10) % 360;
                const [r, g, b] = this.hslToRgb(hue, 100, 50);
                imageData.data[pixelIndex] = r;
                imageData.data[pixelIndex + 1] = g;
                imageData.data[pixelIndex + 2] = b;
            }
            imageData.data[pixelIndex + 3] = 255; // Alpha
        }

        ctx.putImageData(imageData, 0, 0);
        container.appendChild(canvas);
    }

    renderJulia(container, julia) {
        const canvas = document.createElement('canvas');
        canvas.width = julia.width;
        canvas.height = julia.height;
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.imageRendering = 'pixelated';

        const ctx = canvas.getContext('2d');
        const imageData = ctx.createImageData(julia.width, julia.height);

        for (let i = 0; i < julia.data.length; i++) {
            const iteration = julia.data[i];
            const pixelIndex = i * 4;

            if (iteration === julia.max_iterations) {
                // Black for points in the set
                imageData.data[pixelIndex] = 0;
                imageData.data[pixelIndex + 1] = 0;
                imageData.data[pixelIndex + 2] = 0;
            } else {
                // Color based on iteration count
                const hue = (iteration * 10) % 360;
                const [r, g, b] = this.hslToRgb(hue, 100, 50);
                imageData.data[pixelIndex] = r;
                imageData.data[pixelIndex + 1] = g;
                imageData.data[pixelIndex + 2] = b;
            }
            imageData.data[pixelIndex + 3] = 255; // Alpha
        }

        ctx.putImageData(imageData, 0, 0);
        container.appendChild(canvas);
    }

    hslToRgb(h, s, l) {
        h /= 360;
        s /= 100;
        l /= 100;

        const c = (1 - Math.abs(2 * l - 1)) * s;
        const x = c * (1 - Math.abs((h * 6) % 2 - 1));
        const m = l - c / 2;

        let r, g, b;
        if (h >= 0 && h < 1/6) {
            [r, g, b] = [c, x, 0];
        } else if (h >= 1/6 && h < 2/6) {
            [r, g, b] = [x, c, 0];
        } else if (h >= 2/6 && h < 3/6) {
            [r, g, b] = [0, c, x];
        } else if (h >= 3/6 && h < 4/6) {
            [r, g, b] = [0, x, c];
        } else if (h >= 4/6 && h < 5/6) {
            [r, g, b] = [x, 0, c];
        } else {
            [r, g, b] = [c, 0, x];
        }

        return [
            Math.round((r + m) * 255),
            Math.round((g + m) * 255),
            Math.round((b + m) * 255)
        ];
    }

    closeModal() {
        document.getElementById('fractal-modal').style.display = 'none';
    }

    async mineBlock() {
        const mineBtn = document.getElementById('mine-btn');
        const miningStatus = document.getElementById('mining-status');
        
        try {
            mineBtn.disabled = true;
            mineBtn.textContent = 'Mining...';
            miningStatus.style.display = 'block';

            const fractalType = document.getElementById('fractal-type').value;
            const mineRequest = this.buildMineRequest(fractalType);

            const response = await fetch(`${this.API_BASE}/mine`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(mineRequest)
            });

            if (response.ok) {
                const newBlock = await response.json();
                this.blocks.unshift(newBlock);
                this.renderBlocks();
                this.showToast('Block mined successfully!', 'success');
                
                // Update wallet balance
                await this.loadWalletInfo();
            } else {
                throw new Error('Mining failed');
            }
        } catch (error) {
            console.error('Mining error:', error);
            this.showToast('Mining failed', 'error');
        } finally {
            mineBtn.disabled = false;
            mineBtn.textContent = 'Mine Block';
            miningStatus.style.display = 'none';
        }
    }

    buildMineRequest(fractalType) {
        switch (fractalType) {
            case 'Sierpinski':
                return {
                    type: 'Sierpinski',
                    params: {
                        depth: parseInt(document.getElementById('sierpinski-depth').value)
                    }
                };
            case 'Mandelbrot':
                const mandelbrotSize = parseInt(document.getElementById('mandelbrot-size').value);
                return {
                    type: 'Mandelbrot',
                    params: {
                        width: mandelbrotSize,
                        height: mandelbrotSize,
                        x_min: -2.0,
                        x_max: 1.0,
                        y_min: -1.5,
                        y_max: 1.5,
                        max_iterations: parseInt(document.getElementById('mandelbrot-iterations').value)
                    }
                };
            case 'Julia':
                const juliaSize = parseInt(document.getElementById('julia-size').value);
                return {
                    type: 'Julia',
                    params: {
                        width: juliaSize,
                        height: juliaSize,
                        x_min: -1.5,
                        x_max: 1.5,
                        y_min: -1.5,
                        y_max: 1.5,
                        c_real: parseFloat(document.getElementById('julia-c-real').value),
                        c_imag: parseFloat(document.getElementById('julia-c-imag').value),
                        max_iterations: parseInt(document.getElementById('julia-max-iter').value)
                    }
                };
            default:
                throw new Error('Unknown fractal type');
        }
    }

    async sendTransaction() {
        const sendBtn = document.getElementById('send-btn');
        const toAddress = document.getElementById('to-address').value.trim();
        const amount = parseInt(document.getElementById('amount').value);

        if (!toAddress || !amount || amount <= 0) {
            this.showToast('Please enter valid recipient and amount', 'error');
            return;
        }

        try {
            sendBtn.disabled = true;
            sendBtn.textContent = 'Sending...';

            // Get wallet private key from storage
            const walletData = JSON.parse(localStorage.getItem('sierpchain_wallet') || '{}');
            if (!walletData.private_key) {
                throw new Error('No wallet found');
            }

            const response = await fetch(`${this.API_BASE}/transact`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    to: toAddress,
                    amount: amount,
                    private_key: walletData.private_key
                })
            });

            if (response.ok) {
                this.showToast('Transaction sent successfully!', 'success');
                document.getElementById('to-address').value = '';
                document.getElementById('amount').value = '';
                
                // Update wallet balance
                await this.loadWalletInfo();
            } else {
                const error = await response.text();
                throw new Error(error || 'Transaction failed');
            }
        } catch (error) {
            console.error('Transaction error:', error);
            this.showToast(`Transaction failed: ${error.message}`, 'error');
        } finally {
            sendBtn.disabled = false;
            sendBtn.textContent = 'Send';
        }
    }

    setupWebSocket() {
        try {
            const wsUrl = this.API_BASE.replace('https://', 'wss://').replace('http://', 'ws://') + '/ws';
            this.ws = new WebSocket(wsUrl);

            this.ws.onopen = () => {
                console.log('WebSocket connected');
            };

            this.ws.onmessage = (event) => {
                try {
                    const newBlock = JSON.parse(event.data);
                    this.blocks.unshift(newBlock);
                    this.renderBlocks();
                    this.showToast(`New block #${newBlock.index} mined!`, 'success');
                } catch (error) {
                    console.error('WebSocket message error:', error);
                }
            };

            this.ws.onclose = () => {
                console.log('WebSocket disconnected');
                // Attempt to reconnect after 5 seconds
                setTimeout(() => this.setupWebSocket(), 5000);
            };

            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
        } catch (error) {
            console.error('WebSocket setup error:', error);
        }
    }

    hideLoading() {
        document.getElementById('loading').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;

        container.appendChild(toast);

        // Auto remove after 3 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3000);

        // Haptic feedback for Telegram
        if (this.tg.HapticFeedback) {
            this.tg.HapticFeedback.notificationOccurred(type === 'error' ? 'error' : 'success');
        }
    }
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new SierpChainApp();
});

// Handle Telegram WebApp events
window.addEventListener('load', () => {
    if (window.Telegram && window.Telegram.WebApp) {
        window.Telegram.WebApp.ready();
    }
});

