#!/usr/bin/env python3
"""
SierpChain Telegram Bot
Handles bot commands and launches the Mini App
"""

import asyncio
import logging
from telegram import Update, WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot configuration
BOT_TOKEN = "8255421113:AAF7xzXDGD8RxxfkpjM0L08SqTbudJPd_HM"
WEBAPP_URL = "https://lwigtyev.manus.space"  # Deployed Mini App URL

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message with a button that opens the Mini App."""
    user = update.effective_user
    
    # Create the Mini App button
    keyboard = [
        [InlineKeyboardButton(
            "🔺 Launch SierpChain", 
            web_app=WebAppInfo(url=WEBAPP_URL)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_message = f"""
🔺 *Welcome to SierpChain, {user.first_name}!*

SierpChain is a revolutionary blockchain that transforms mining into mathematical art. Every block contains beautiful fractal patterns - Sierpinski triangles, Mandelbrot sets, and Julia sets.

✨ *Features:*
• Mine blocks with fractal patterns
• Send and receive SIERP tokens
• Explore the blockchain as living art
• Real-time fractal visualization

Tap the button below to launch the Mini App and start exploring!
    """
    
    await update.message.reply_text(
        welcome_message,
        parse_mode='Markdown',
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a help message."""
    help_text = """
🔺 *SierpChain Bot Commands:*

/start - Launch the SierpChain Mini App
/help - Show this help message
/about - Learn more about SierpChain

*What is SierpChain?*
SierpChain is an experimental blockchain that integrates Sierpinski triangle fractal patterns into its core architecture. Unlike traditional blockchains that waste computational energy on arbitrary calculations, SierpChain channels that energy into generating mathematically elegant fractal patterns.

*How it works:*
• Each block contains a unique fractal pattern
• Mining difficulty scales with fractal complexity
• Computational work produces lasting mathematical beauty
• Visual verification makes blockchain exploration intuitive

Launch the Mini App to start mining, trading, and exploring!
    """
    
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send information about SierpChain."""
    about_text = """
🔺 *About SierpChain*

SierpChain revolutionizes blockchain technology by integrating fractal mathematics into distributed ledger systems. 

*Key Innovations:*
• **Fractal Proof-of-Work**: Mining generates Sierpinski triangles, Mandelbrot sets, and Julia sets
• **Visual Verification**: Block validity can be seen and computed mathematically  
• **Meaningful Mining**: Computational work creates lasting mathematical beauty
• **Scalable Complexity**: Fractal depth determines mining difficulty

*Technical Stack:*
• Backend: Rust with Actix-Web
• Frontend: HTML5/CSS3/JavaScript
• Fractals: Advanced mathematical algorithms
• P2P Network: libp2p for distributed communication

*Created by:* The SierpChain Development Team
*License:* Open Source
*Repository:* github.com/zalgorythm/SierpChain

Launch the Mini App to experience the future of blockchain!
    """
    
    await update.message.reply_text(about_text, parse_mode='Markdown')

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log the error and send a telegram message to notify the developer."""
    logger.error(msg="Exception while handling an update:", exc_info=context.error)

def main() -> None:
    """Start the bot."""
    # Create the Application
    application = Application.builder().token(BOT_TOKEN).build()

    # Register handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("about", about))
    
    # Register error handler
    application.add_error_handler(error_handler)

    # Run the bot until the user presses Ctrl-C
    print("🔺 SierpChain Bot is starting...")
    print(f"Bot Token: {BOT_TOKEN[:10]}...")
    print(f"Mini App URL: {WEBAPP_URL}")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()

