# SierpChain Telegram Mini App

## 🔺 Overview

This is the Telegram Mini App version of SierpChain - a revolutionary blockchain that transforms mining into mathematical art. The Mini App provides a mobile-friendly interface for interacting with the SierpChain blockchain directly within Telegram.

## 🚀 Deployment Information

- **Mini App URL**: https://lwigtyev.manus.space
- **Bot Username**: @sierpchainbot
- **Bot Token**: 8255421113:AAF7xzXDGD8RxxfkpjM0L08SqTbudJPd_HM
- **Backend API**: https://sentences-ads-arabia-rom.trycloudflare.com

## 📱 Features

### Wallet Management
- View wallet address and balance
- Send SIERP tokens to other addresses
- Automatic wallet creation for new users

### Mining Interface
- Mine new blocks with different fractal types:
  - **Sierpinski Triangles**: Adjustable depth (3-8)
  - **Mandelbrot Sets**: Configurable size and iterations
  - **Julia Sets**: Customizable parameters and complexity
- Real-time mining progress indication
- Automatic balance updates after successful mining

### Blockchain Explorer
- View recent blocks with fractal previews
- Interactive block details with full fractal visualization
- Real-time updates via WebSocket connection
- Mobile-optimized fractal rendering

### Telegram Integration
- Native Telegram theme support (light/dark mode)
- Haptic feedback for user interactions
- Toast notifications for actions
- Responsive design optimized for mobile devices

## 🛠️ Technical Architecture

### Frontend (Mini App)
- **Technology**: Pure HTML5, CSS3, JavaScript (ES6+)
- **Framework**: Vanilla JS with Telegram WebApp API
- **Styling**: CSS Grid/Flexbox with Telegram theme variables
- **Graphics**: SVG for Sierpinski triangles, Canvas for complex fractals

### Backend Integration
- **API Base**: Cloudflare tunnel to Rust backend
- **WebSocket**: Real-time block updates
- **CORS**: Configured for cross-origin requests
- **Authentication**: Wallet-based with private key storage

### Bot Handler
- **Language**: Python with python-telegram-bot library
- **Commands**: /start, /help, /about
- **Features**: Inline keyboard with Mini App launch button

## 📁 File Structure

```
telegram-miniapp/
├── index.html          # Main Mini App interface
├── styles.css          # Telegram-optimized styling
├── app.js              # Core application logic
├── manifest.json       # Web App manifest
├── icon-192.png        # App icon (192x192)
├── icon-512.png        # App icon (512x512)
├── telegram-bot.py     # Bot command handler
├── requirements.txt    # Python dependencies
└── README.md           # This documentation
```

## 🎨 Design Features

### Responsive Layout
- Mobile-first design approach
- Touch-friendly interface elements
- Optimized for Telegram's viewport constraints
- Adaptive typography and spacing

### Theme Integration
- Automatic Telegram theme detection
- CSS custom properties for theme colors
- Dark mode support
- Consistent with Telegram's design language

### Visual Elements
- Gradient headers with fractal branding
- Card-based layout for content sections
- Interactive range sliders for parameters
- Animated loading states and progress bars

## 🔧 Setup Instructions

### For Bot Administrators

1. **Configure Bot with @BotFather**:
   ```
   /newbot
   Name: SierpChain
   Username: sierpchainbot
   
   /newapp
   Select: @sierpchainbot
   Title: SierpChain
   Description: Fractal Blockchain Explorer
   Photo: Upload icon-512.png
   Web App URL: https://lwigtyev.manus.space
   ```

2. **Set Bot Commands**:
   ```
   /setcommands
   start - Launch SierpChain Mini App
   help - Get help and information
   about - Learn about SierpChain
   ```

3. **Configure Menu Button**:
   ```
   /setmenubutton
   Select: @sierpchainbot
   Button text: 🔺 SierpChain
   Web App URL: https://lwigtyev.manus.space
   ```

### For Developers

1. **Install Bot Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Bot Handler**:
   ```bash
   python telegram-bot.py
   ```

3. **Test Mini App**:
   - Open Telegram
   - Search for @sierpchainbot
   - Send /start command
   - Tap "🔺 Launch SierpChain" button

## 🔐 Security Considerations

### Wallet Security
- Private keys stored in localStorage (development)
- **Production**: Implement secure key management
- **Recommendation**: Use Telegram's CloudStorage API

### API Security
- CORS configured for specific origins
- Rate limiting on backend endpoints
- Input validation for all user data

### Bot Security
- Token stored securely (environment variables recommended)
- Error handling prevents information leakage
- User input sanitization

## 🚀 Performance Optimizations

### Frontend
- Lazy loading for fractal visualizations
- Efficient Canvas/SVG rendering
- Minimal JavaScript bundle size
- CSS animations for smooth interactions

### Backend Communication
- WebSocket for real-time updates
- Efficient JSON serialization
- Connection pooling and retry logic
- Graceful error handling

## 🐛 Known Issues & Limitations

### Current Limitations
1. **Wallet Storage**: Uses localStorage (not secure for production)
2. **Offline Support**: Limited offline functionality
3. **Large Fractals**: Performance impact on older devices
4. **WebSocket**: May disconnect on network changes

### Planned Improvements
1. **Secure Storage**: Implement Telegram CloudStorage
2. **Progressive Web App**: Add service worker for offline support
3. **Performance**: Optimize fractal rendering algorithms
4. **Features**: Add transaction history and advanced mining options

## 📊 API Endpoints Used

### Wallet Operations
- `GET /wallet/info` - Get wallet information
- `POST /wallet` - Create new wallet
- `POST /transact` - Send transaction

### Mining Operations
- `POST /mine` - Mine new block with fractal parameters
- `GET /blocks` - Get blockchain data

### Real-time Updates
- `WebSocket /ws` - Real-time block notifications

## 🎯 User Experience Flow

1. **First Launch**:
   - User taps Mini App button in Telegram
   - App initializes with Telegram theme
   - Wallet created automatically if none exists
   - Welcome message displayed

2. **Mining Flow**:
   - User selects fractal type and parameters
   - Taps "Mine Block" button
   - Progress indicator shows mining status
   - Success notification and balance update

3. **Transaction Flow**:
   - User enters recipient address and amount
   - Taps "Send" button
   - Transaction submitted to network
   - Confirmation and balance update

4. **Exploration Flow**:
   - User browses recent blocks
   - Taps block to view details
   - Modal shows full fractal visualization
   - Block information displayed

## 🔄 Update Process

### Mini App Updates
1. Update files in `/telegram-miniapp/` directory
2. Redeploy using deployment service
3. Changes automatically available to users

### Bot Updates
1. Update `telegram-bot.py`
2. Restart bot service
3. New commands immediately available

## 📞 Support & Contact

For technical support or questions about the SierpChain Telegram Mini App:

- **Repository**: https://github.com/zalgorythm/SierpChain
- **Issues**: Create GitHub issue for bug reports
- **Telegram**: Contact @sierpchainbot for user support

## 📄 License

This project is open source and available under the same license as the main SierpChain project.

---

*Built with ❤️ for the Telegram Mini App ecosystem*

